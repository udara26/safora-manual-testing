import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Test_7 {
    public static void main(String args[]) throws InterruptedException {
        WebDriver driver =  new ChromeDriver();
        driver.get("https://safora.se/en/contact.html");
// Maximize Browser
        driver.manage().window().maximize();
        // Fill Name
        driver.findElement(By.name("name"))
                .sendKeys("Udara Shalini");
        Thread.sleep(1500);
        // Fill Email
        driver.findElement(By.name("email"))
                .sendKeys("udara@gmail.com");
        Thread.sleep(1500);
        // Fill Phone Number
        driver.findElement(By.name("phone"))
                .sendKeys("077123456712345");
        Thread.sleep(3500);
        driver.findElement(By.name("message"))
                .sendKeys("This is a Selenium automation test.");
        Thread.sleep(15000);

        // Pause for Manual CAPTCHA
        System.out.println("Please complete CAPTCHA manually...");
        Thread.sleep(20000);

        JavascriptExecutor js =
                (JavascriptExecutor) driver;

        WebElement sendBtn =
                driver.findElement(
                        By.cssSelector("button.rs-btn.has-theme-red"));

        js.executeScript("arguments[0].click();", sendBtn);
        Thread.sleep(1500);
        WebDriverWait wait =
                new WebDriverWait(driver, Duration.ofSeconds(10));

        WebElement okBtn = wait.until(
                ExpectedConditions.elementToBeClickable(
                        By.cssSelector("button.swal2-confirm.swal2-styled")));

        okBtn.click();
        driver.close();
    }
}

